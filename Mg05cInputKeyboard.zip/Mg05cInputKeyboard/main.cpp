#include <windows.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include<iostream>

using namespace std;

bool warna = true;
float posX = 0.0;
float posY = 0.0;

void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	glPointSize(4);

	glBegin(GL_POLYGON);
	glVertex2f(-1.0+posX,-1.0+posY);
	glVertex2f(1.0+posX,-1.0+posY);
	glVertex2f(0.0+posX,1.0+posY);
	glEnd();
	glFlush();
}

void inputan(unsigned char key, int x, int y){

    if(key=='r' || key == 'R'){
        posX += 0.2;
       cout << posX << endl;
        display();
    }
    if(key == 'l' || key == 'L'){
        posX -= 0.2;
        cout << posX << endl;
        display();
    }

    if(key == 'a' || key == 'A'){
        posY += 0.2;
        cout << posY << endl;
        display();
        }
    if(key == 'b' || key == 'B'){
        posY -= 0.2;
        cout << posY << endl;
        display();
    }
}

void myinit(){
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-7.0,7.0,-7.0,7.0);
	glMatrixMode(GL_MODELVIEW);
	glClearColor(1.0,1.0,1.0,1.0);
	glColor3f(0.0,0.0,1.0);
}

int main(int argc, char* argv[]){
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(700,700);
	//glutInitWindowPosition(100,100);
	glutCreateWindow("Segitiga Titik");
	glutDisplayFunc(display);
	glutKeyboardFunc(inputan);
	myinit();
	glutMainLoop();

	return 0;
}
